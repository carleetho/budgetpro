# REGLAS DE NEGOCIO — FINANZAS / ALERTAS PARAMÉTRICAS

## 1. Propósito
Documentar las reglas paramétricas vigentes para alertas técnicas.

## 2. Reglas canónicas
- Maquinaria: costo_horario = 0 en equipo propio → alerta crítica.
- Ratio Acero/Concreto fuera de rango 80–150 kg/m³ → alerta warning.
- Tamaño de agregado > 1/5 del ancho del elemento → alerta warning.

