# Reporte — Sprint 1 (Decisiones Canónicas)

## Responsable
- Arquitecto de Dominio / PO

## Entregables
- `docs/decisiones/DECISION_ESTADOS_PROYECTO.md`
- `docs/decisiones/DECISION_ESTADOS_PRESUPUESTO.md`
- `docs/decisiones/DECISION_COBRO_EVIDENCIA.md`
- `docs/decisiones/DECISION_COMPRA_SIN_PARTIDA.md`
- `docs/decisiones/DECISION_ANTICIPO_AMORTIZACION.md`
- `docs/decisiones/DECISION_SALDO_DISPONIBLE_PARTIDA_APU.md`

