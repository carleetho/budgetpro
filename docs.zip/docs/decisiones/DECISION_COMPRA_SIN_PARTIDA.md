# DECISIÓN CANÓNICA — COMPRA SIN PARTIDA

## Fuentes canónicas
- `docs/modules/COMPRAS_SPECS.md`
- `docs/audits/FASE2_DIAGNOSTICO_DOMINIO_BUDGETPRO.md`
- `docs/audits/FASE3_INVENTARIO_CANONICO_REGLAS_EXISTENTES.md`

## Decisión
- Compra sin Partida es válida **si está clasificada**.
- Compra sin clasificación es ilegal.

