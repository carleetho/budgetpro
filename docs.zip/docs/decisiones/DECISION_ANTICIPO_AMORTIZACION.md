# DECISIÓN CANÓNICA — ANTICIPO Y AMORTIZACIÓN

## Fuentes canónicas
- `docs/audits/FASE2_DIAGNOSTICO_DOMINIO_BUDGETPRO.md`
- `docs/audits/FASE3_INVENTARIO_CANONICO_REGLAS_EXISTENTES.md`

## Decisión
- El saldo pendiente de anticipo proviene de eventos/registro de anticipo.
- No se amortiza si no existe anticipo registrado.
- No se permite saldo ficticio.

