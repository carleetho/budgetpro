# DECISIÓN CANÓNICA — COBRO CON EVIDENCIA

## Fuentes canónicas
- Regla documental: “No hay cobro sin evidencia”.
- `docs/audits/FASE2_DIAGNOSTICO_DOMINIO_BUDGETPRO.md` (CD-04 / RS-01)
- `docs/audits/FASE3_INVENTARIO_CANONICO_REGLAS_EXISTENTES.md` (RCON-04)

## Decisión
- No se permite aprobar estimación sin evidencia contractual válida.
- La evidencia es requisito previo al cobro.
- No existe ingreso provisional ni diferido sin evidencia.

